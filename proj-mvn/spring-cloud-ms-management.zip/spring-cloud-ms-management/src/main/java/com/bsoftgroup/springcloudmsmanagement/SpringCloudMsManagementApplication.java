package com.bsoftgroup.springcloudmsmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudMsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudMsManagementApplication.class, args);
	}

}
