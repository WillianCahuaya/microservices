package com.boomdev.onlinesale.onlinesalemsconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSaleMsConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineSaleMsConfigServerApplication.class, args);
	}

}
